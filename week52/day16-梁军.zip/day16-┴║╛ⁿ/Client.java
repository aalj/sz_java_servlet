/**
 * Client.java
 * zuoye
 *
 * Function�� TODO 
 *
 *   ver     date      		author
 * ��������������������������������������������������������������������
 *   		 2015��12��22�� 		liang
 *
 * Copyright (c) 2015, TNT All Rights Reserved.
*/

package zuoye;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * ClassName:Client Function: TODO ADD FUNCTION Reason: TODO ADD REASON
 *
 * @author liang
 * @version
 * @since Ver 1.1
 * @Date 2015��12��22�� ����4:42:05
 *
 * @see
 * 
 */
public class Client {

	public static void main(String[] args) {
		try {
			// ����socket����
			Socket socket = new Socket("localhost", 9009);
			new Thread(new SocketSend(socket)).start();
			new Thread(new SocketReceiver(socket)).start();

		} catch (IOException e) {

			//
			e.printStackTrace();

		}

	}

}

class SocketSend implements Runnable {
	private Socket socket = null;
	private PrintStream print = null;
	Scanner scan = new Scanner(System.in);

	public SocketSend(Socket socket) {
		this.socket = socket;
	}

	@Override
	public void run() {
		try {
			print = new PrintStream(socket.getOutputStream());
			while(true){
				String nextLine = scan.nextLine();
				
			print.println(nextLine);
			print.flush();
			}

		} catch (IOException e) {

			//
			e.printStackTrace();

		} finally {
			try {
				if (socket != null)
					socket.close();
				if (print != null)
					print.close();
			} catch (Exception e2) {
				// TODO: handle exception
			}

		}

	}

}

class SocketReceiver implements Runnable {
	private Socket socke = null;
	private BufferedWriter bufferedWriter;
	private BufferedReader buffer;

	public SocketReceiver(Socket socke) {
		super();
		this.socke = socke;
	}

	@Override
	public void run() {
		try {

			File file = new File("G:\\SuZhou_Android\\week52\\day2\\src\\zuoye\\copy.txt");
			bufferedWriter = new BufferedWriter(new FileWriter(file));
			
			//���շ�������û����
			buffer = new BufferedReader(new InputStreamReader(socke.getInputStream()));
			String i = null;
			while ((i = buffer.readLine()) != null) {
				bufferedWriter.write(i);
			}

		} catch (IOException e) {

			//
			e.printStackTrace();

		} finally {
			if (bufferedWriter != null) {
				try {
					bufferedWriter.close();
				} catch (IOException e) {
					
					//
					e.printStackTrace();
					
				}
			}
		}

	}

}
