/**
 * Course.java
 * zuoye
 *
 * Function： TODO 
 *
 *   ver     date      		author
 * ──────────────────────────────────
 *   		 2015年12月14日 		Stone_A
 *
 * Copyright (c) 2015, TNT All Rights Reserved.
*/

package zuoye;

import java.util.HashMap;
import java.util.Map;

/**
 * ClassName:Course Function: TODO ADD FUNCTION Reason: TODO ADD REASON
 *
 * @author Stone_A
 * @version
 * @since Ver 1.1
 * @Date 2015年12月14日 下午6:11:42
 *
 * @see
 * 
 */
public class Course {
	/**
	 * 学科名字
	 */
	private String couName;
	/**
	 * 学生成绩
	 */
	private int couGrade;
	public Course() {

		// TODO Auto-generated constructor stub

	}
	public Course(String couName, int couGrade) {
		super();
		this.couName = couName;
		this.couGrade = couGrade;
		//通过构照方法就把数据存到map集合里面
	}

	

	public int getCouGrade() {
		return couGrade;
	}

	@Override
	public String toString() {
		return "couName=" + couName + ", couGrade=" + couGrade ;
	}
	public void setCouGrade(int couGrade) {
		this.couGrade = couGrade;
	}

	public String getCouName() {
		return couName;
	}

	public void setCouName(String couName) {
		this.couName = couName;
	}

}
