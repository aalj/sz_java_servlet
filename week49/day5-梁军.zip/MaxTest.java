package zuoye;
/*
 * /*
 * 1、（静态方法、重载）编写一个程序，要求提供三个静态方法，方法名统一为max，要求如下：
a)	第一个方法提供两个整型参数，求最大整数
b)	第二个方法提供两个双精度数，求最大双精度数
c)	第三个方法提供三个双精度数，求最大双精度数
d)	在main方法中分别调用这三个方法，在控制台输出三个方法的返回值
	[Max.java]

 */
 
public class MaxTest {

	public static void main(String[] args) {
		System.out.println("两个整数中最大整数"+Max.max(4, 5));
		System.out.println("两个双进度最大数"+Max.max(2.0, 9.0));
		System.out.println("三个双进度最大数"+Max.max(4.6,4.5, 5.2));
		
	}

}
