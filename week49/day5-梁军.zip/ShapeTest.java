package zuoye;

/*
 *A、 Circle 类（圆形），属性：半径；方法：求周长、求面积
	B、 Rect 类（矩形），属性：长、宽；方法：求周长、求面积
	C、 Square 类（正方形），属性：边长；方法：求周长、求面积
	提示：
	1） 这三个类均具有求周长和面积的方法；
	2） 正方形是特殊的矩形；
 
 */
public class ShapeTest {
	public static void main(String[] args) {
		System.out.println("测试");
		Circle circle = new
				Circle(6);
		System.out.println("输出面积");
		System.out.println("输出面积是\t"+circle.area());
		System.out.println("输出周长");
		System.out.println("输出周长是\t"+circle.girth());
		Rect rect =new Rect(5.6,56.6) ;
		System.out.println("输出面积");
		System.out.println("输出面积是\t"+rect.area());
		System.out.println("输出周长");
		System.out.println("输出周长是\t"+rect.girth());
		Square square  =new Square(5);
		System.out.println("输出面积");
		System.out.println("输出面积是\t"+square.area());
		System.out.println("输出周长");
		System.out.println("输出周长是\t"+square.girth());
		
	}

}

class Circle extends Shape {
	private double size = 10;

	public Circle(double size) {
		this.size = size;
	}

	@Override
	public double area() {

		return size * size * 3.1415926;
	}

	@Override
	public double girth() {

		return 2 * size * 3.1415926;
	}

	@Override
	public void draw() {
		System.out.println("这是圆形");
	}
}

class Rect extends Shape {
	private double g = 0;
	private double w = 0;

	public Rect() {

	}

	public Rect(double g, double w) {
		this.g = g;
		this.w = w;
	}

	@Override
	public double area() {

		return g * w;
	}

	@Override
	public double girth() {

		return 2 * (g + w);
	}

	@Override
	public void draw() {
		System.out.println("这是矩形");
	}
}

class Square extends Rect {
	private double g = 0;

	public Square(double g) {
		this.g = g;
	}

	@Override
	public double area() {

		return g * g;
	}

	@Override
	public double girth() {

		return 2 * (g + g);
	}

	@Override
	public void draw() {
		System.out.println("这是正方形");
	}

}

class Shape {
	public double area() {

		return 0;
	}

	public double girth() {

		return 0;
	}

	public void draw() {

	}
}