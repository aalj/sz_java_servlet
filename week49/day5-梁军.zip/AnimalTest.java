package zuoye;
/*
 * （*继承）有一个动物类Animal，有眼睛eyes 和 腿legs二个属性，yaff()叫和run()跑二个方法。
class Animal{
	protected int eyes=2;
	protected int legs;
	public Animal(){
		this.legs=2;
	}
	public void yaff(){
		System.out.println( “动物叫声”);
	}
	public void run(){
		System.out.println( “动物跑动”);
	}
}
	A、分别定义二个子类 Duck(鸭子)类和 Dog(狗)类，继承自Animal类。 请重写父类的yaff()和run()方法，详细输出鸭子和狗的叫声和跑动。
	B、写Dog类的构造方法，给legs的腿数赋值4
	C．再定义一个DogPet类，继承自Dog类；子类添加name（宠物名字）属性和getName（）, setName（String name）二个方法，实现赋值和取值的功能。
	D.分别创建Duck、Dog、DogPet对象，分别调用其yaff及run方法.
[AnimalTest.java  Animal等类写在该文件中]

 */
public class AnimalTest {
	public static void main(String[] args) {
		Duck duck = new Duck();
		Dog dog  = new Dog() ;
		DogPet dogPet = new DogPet(); 
		System.out.println("对象鸭子对象");
		duck.run();
		duck.yaff();
		System.out.println("对象Dog对象");
		dog.run();dog.yaff();
		System.out.println("对象DogPet对象");
		dogPet.run();
		dogPet.yaff();
		System.out.println("使用宠物狗的get set 方法");
		dogPet.setName("鸭子");
		System.out.println("宠物狗的名字叫    "+dogPet.getName());
		
		
	}
	
	
	
}
class Animal{
	protected int eyes=2;
	protected int legs;
	public Animal(){
		this.legs=2;
	}
	public void yaff(){
		System.out.println( "动物叫声");
	}
	public void run(){
		System.out.println( "动物跑动");
	}
}
/**
 * A、分别定义二个子类 Duck(鸭子)类和 Dog(狗)类，继承自Animal类。 请重写父类的yaff()和run()方法，详细输出鸭子和狗的叫声和跑动。
 * @author Gemptc
 *
 */
class Duck extends Animal{
	
	
	@Override
	public void yaff() {
		System.out.println("嘎嘎   嘎嘎嘎   嘎嘎嘎嘎");
		super.yaff();
	}
	@Override
	public void run() {
		System.out.println("鸭子跑步");
		super.run();
	}
	
}
/**
 * B、写Dog类的构造方法，给legs的腿数赋值4
 * @author Gemptc
 *
 */
class Dog extends Animal{
	
	public Dog() {
		this.legs = 4;
	}
}
	
	/**
	 * C．再定义一个DogPet类，继承自Dog类；子类添加name（宠物名字）属性和getName（）, setName（String name）二个方法，实现赋值和取值的功能。
	 * @author Gemptc
	 *
	 */
	class DogPet extends Dog{
		private String name = null;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
	}
	

