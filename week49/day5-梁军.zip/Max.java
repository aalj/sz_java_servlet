package zuoye;
/*
 * 1、（静态方法、重载）编写一个程序，要求提供三个静态方法，方法名统一为max，要求如下：
a)	第一个方法提供两个整型参数，求最大整数
b)	第二个方法提供两个双精度数，求最大双精度数
c)	第三个方法提供三个双精度数，求最大双精度数
d)	在main方法中分别调用这三个方法，在控制台输出三个方法的返回值
	[Max.java]

 */
public class Max {
   public static int max(int a,int b){
	   if(a<=b)
		   return b;
	   else{
		   return a;
	   }
}
   
   public static double max(double a,double b,double c){
	   if(a>b){
		   if(a>c){
			   return a;
		   }else{//a<c
			   return c;
		   }
	   }else{//a<b
		   if(b>c){
			   return b;
		   }else{
			   return c;
		   }
	   }
	   
	   
	   
}
   public static double max(double a,double b){
	   if(a>b){
		   return a;
	   }else{
		   return b;
	   }
}
}
