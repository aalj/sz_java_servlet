package zuoye;

public class SingletonTest {

	public static void main(String[] args) {
		System.out.println("使用懒汉模式创建对象");
		Singleton singleton1 = Singleton.getInsatnce() ;
		Singleton singleton   =   Singleton.getInsatnce();
		if(singleton==singleton1){
			System.out.println("创建的是同一个对象");
		}else{
			System.out.println("单例模式失败");
		}

	}
	
}

class Singleton{
	private static Singleton singleton =null;
	private  Singleton() {
		// TODO Auto-generated constructor stub
	}
	public static Singleton getInsatnce(){
		if(singleton==null){
			singleton = new Singleton() ;
		}
		return singleton;
		
	}
}